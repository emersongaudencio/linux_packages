Authors
=======

The code for mydumper has been written by the following people:

  * `Domas Mituzas <http://dom.as/>`_, Facebook ( domas at fb dot com )
  * `Andrew Hutchings <http://www.linuxjedi.co.uk>`_, SkySQL ( andrew at skysql dot com )
  * `Mark Leith <http://www.markleith.co.uk/>`_, Oracle Corporation ( mark dot leith at oracle dot com )
  * `Max Bubenick <http://www.bube.com.ar>`_, Percona RDBA ( max dot bubenick at percona dot com )
