.. MySQL Data Dumper documentation master file
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MySQL Data Dumper's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2

   authors
   compiling
   mydumper_usage
   myloader_usage
   files
   examples

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

