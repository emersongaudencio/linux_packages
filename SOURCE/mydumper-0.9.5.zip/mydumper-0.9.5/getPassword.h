#ifndef GET_PASSWORD_PROMPT
	#define GET_PASSWORD_PROMPT
	char* passwordPrompt(void);
#endif
